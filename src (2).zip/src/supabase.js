import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
export const isCloudConfigured = Boolean(url && key && !url.includes("YOUR-PROJECT") && !key.includes("YOUR_"));
export const supabase = isCloudConfigured ? createClient(url, key) : null;
